# Lockless Swap

No one likes locking (pun intended) in Pancakeswap, so we removed it. 