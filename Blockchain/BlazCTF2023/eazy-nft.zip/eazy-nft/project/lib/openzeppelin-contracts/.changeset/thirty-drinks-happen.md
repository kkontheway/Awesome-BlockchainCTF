---
'openzeppelin-solidity': major
---

`AccessManager`: Make `schedule` and `execute` more conservative when delay is 0.
