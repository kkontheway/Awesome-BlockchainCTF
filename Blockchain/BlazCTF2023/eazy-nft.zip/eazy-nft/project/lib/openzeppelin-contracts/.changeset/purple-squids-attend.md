---
'openzeppelin-solidity': patch
---

`AccessManager`: Use named return parameters in functions that return multiple values.
pr: #4624
